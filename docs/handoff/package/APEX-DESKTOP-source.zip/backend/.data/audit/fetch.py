"""Audit harness: pull app API responses and raw Alpaca responses side by side.

Writes JSON under backend/.data/audit/<TICKER>/. Not part of the app.
"""
from __future__ import annotations

import asyncio
import json
import sys
from datetime import date, datetime, timezone
from pathlib import Path

import httpx
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parent
ENV = dotenv_values(ROOT.parents[2] / ".env")
H = {"APCA-API-KEY-ID": ENV["ALPACA_API_KEY_ID"], "APCA-API-SECRET-KEY": ENV["ALPACA_API_SECRET_KEY"]}
APP = "http://127.0.0.1:8101"
DATA = "https://data.alpaca.markets"
BROKER = "https://paper-api.alpaca.markets"
TICKERS = sys.argv[1:] or ["AAPL", "NVDA", "TSLA", "SPY", "KO", "MU"]


def save(t: str, name: str, payload) -> None:
    d = ROOT / t
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.json").write_text(json.dumps(payload, indent=1, default=str))


async def token(c: httpx.AsyncClient) -> str:
    await c.post(f"{APP}/auth/login", json={"username": "trader", "password": "ApexDemo!23"})
    code = (await c.post(f"{APP}/auth/otp/request", json={"username": "trader"})).json()["code"]
    return (await c.post(f"{APP}/auth/otp/verify", json={"username": "trader", "code": code})).json()["access_token"]


async def alp(c: httpx.AsyncClient, base: str, path: str, params: dict | None = None):
    r = await c.get(base + path, headers=H, params=params, timeout=30)
    return {"status": r.status_code, "body": r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text[:500]}


async def alp_paged(c, base, path, params, key):
    out, token_, pages = ({} if key == "snapshots" else []), None, 0
    while True:
        p = dict(params)
        if token_:
            p["page_token"] = token_
        r = await c.get(base + path, headers=H, params=p, timeout=30)
        pages += 1
        body = r.json()
        chunk = body.get(key) or ({} if key == "snapshots" else [])
        if key == "snapshots":
            out.update(chunk)
        else:
            out.extend(chunk)
        token_ = body.get("next_page_token")
        if not token_ or pages > 60:
            break
    return out


def pick_expiries(exps: list[dict]) -> list[str]:
    """One near weekly (~7-14 DTE) and one ~30-45 DTE monthly-ish."""
    near = [e for e in exps if 5 <= e["dte"] <= 14]
    mid_ = [e for e in exps if 25 <= e["dte"] <= 50]
    picks = []
    if near:
        picks.append(near[0]["date"])
    if mid_:
        # prefer 3rd-Friday style monthly
        monthly = [e for e in mid_ if 15 <= int(e["date"][8:10]) <= 21 and date.fromisoformat(e["date"]).weekday() == 4]
        picks.append((monthly or mid_)[0]["date"])
    return picks


async def run_ticker(c: httpx.AsyncClient, auth: dict, t: str) -> None:
    today = datetime.now(timezone.utc).date().isoformat()
    # ---- quotes
    save(t, "app_quote", (await c.get(f"{APP}/market/quote/{t}", timeout=60)).json())
    for feed in ("iex", "delayed_sip"):
        save(t, f"alp_snapshot_{feed}", await alp(c, DATA, f"/v2/stocks/{t}/snapshot", {"feed": feed}))
    # ---- bars
    for tf, alp_tf in (("1D", "1Day"), ("1H", "1Hour"), ("5m", "5Min"), ("1W", "1Week")):
        save(t, f"app_bars_{tf}", (await c.get(f"{APP}/market/bars/{t}", params={"timeframe": tf, "limit": 400}, timeout=60)).json())
    # ---- expirations
    exps = (await c.get(f"{APP}/market/expirations/{t}", timeout=120)).json()
    save(t, "app_expirations", exps)
    contracts = await alp_paged(
        c, BROKER, "/v2/options/contracts",
        {"underlying_symbols": t, "status": "active", "limit": 1000, "expiration_date_gte": today, "type": "call"},
        "option_contracts",
    )
    save(t, "alp_contract_calls_all", contracts)
    picks = pick_expiries(exps.get("expirations") or [])
    save(t, "picked_expiries", picks)
    for e in picks:
        save(t, f"app_chain_{e}", (await c.get(f"{APP}/market/options/{t}", params={"expiry": e}, timeout=120)).json())
        snaps = await alp_paged(c, DATA, f"/v1beta1/options/snapshots/{t}", {"expiration_date": e, "limit": 1000, "feed": "indicative"}, "snapshots")
        save(t, f"alp_snapshots_{e}", snaps)
        meta = await alp_paged(c, BROKER, "/v2/options/contracts", {"underlying_symbols": t, "status": "active", "limit": 1000, "expiration_date": e}, "option_contracts")
        save(t, f"alp_contracts_{e}", meta)
        save(t, f"app_chain_analysis_{e}", (await c.get(f"{APP}/market/options/{t}/analysis", params={"expiry": e}, timeout=120)).json())
        save(t, f"app_vol_{e}", (await c.get(f"{APP}/volatility/{t}", params={"expiry": e}, timeout=180)).json())
    # ---- raw daily bars (same params as app, plus explicit sip for official OHLCV)
    save(t, "alp_bars_1D_default", await alp(c, DATA, f"/v2/stocks/{t}/bars", {"timeframe": "1Day", "limit": 400, "adjustment": "raw", "start": "2025-08-01"}))
    save(t, "alp_bars_1D_iex", await alp(c, DATA, f"/v2/stocks/{t}/bars", {"timeframe": "1Day", "limit": 400, "adjustment": "raw", "start": "2025-08-01", "feed": "iex"}))
    save(t, "alp_bars_1H_default", await alp(c, DATA, f"/v2/stocks/{t}/bars", {"timeframe": "1Hour", "limit": 400, "adjustment": "raw", "start": "2026-08-20"}))
    save(t, "alp_bars_5m_default", await alp(c, DATA, f"/v2/stocks/{t}/bars", {"timeframe": "5Min", "limit": 400, "adjustment": "raw", "start": "2026-09-18"}))
    # ---- scan (uses nearest ~30-45 DTE pick when present)
    scan_exp = picks[-1] if picks else None
    now = datetime.now(timezone.utc).isoformat()
    body = {
        "snapshot": {"symbol": t, "timeframe": "1D", "visible_from": "2026-03-01T00:00:00Z", "visible_to": now, "studies": ["ema", "macd", "rsi"], "captured_at": now},
        "expiry": scan_exp,
    }
    r = await c.post(f"{APP}/scan", json=body, headers=auth, timeout=300)
    save(t, "app_scan", r.json() if r.status_code == 200 else {"status": r.status_code, "text": r.text[:2000]})
    save(t, "app_fund_deep", (await c.get(f"{APP}/market/fundamentals/{t}/deep", timeout=120)).json())
    save(t, "app_events", (await c.get(f"{APP}/volatility/{t}/events", timeout=120)).json())
    print(t, "done", picks, flush=True)


async def main() -> None:
    async with httpx.AsyncClient() as c:
        tok = await token(c)
        auth = {"Authorization": f"Bearer {tok}"}
        save("_meta", "clock", await alp(c, BROKER, "/v2/clock"))
        for t in TICKERS:
            try:
                await run_ticker(c, auth, t)
            except Exception as exc:  # noqa: BLE001
                print(t, "FAILED", repr(exc), flush=True)


asyncio.run(main())
